from django.contrib import admin
from home.models import Cart,shop

# Register your models here.
admin.site.register(Cart)
admin.site.register(shop)